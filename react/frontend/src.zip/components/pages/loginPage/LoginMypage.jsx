import React, { useState } from 'react';
import AvatarSection from '../components/mypage/AvatarSection';
import { Box, createTheme, ThemeProvider, Typography } from '@mui/material';
import ActivitySection from '../components/mypage/ActivitySection';
import MyInformation from '../components/mypage/MyInformation';
import '.'
import LoginNavbar from '../loginPage/loginbar/LoginNavbar';
import LoginMainBar from '../loginPage/loginbar/LoginMainBar';

const LoginMypage = () => {
  const [mode, setMode] = useState("light");
    const darkTheme = createTheme({
    palette: {
      mode: mode,
    },
    typography: {
      fontFamily: "Gaegu, sans-serif",
    },
  });

  return (
    <ThemeProvider theme={darkTheme}>
      <LoginNavbar />
      <LoginMainBar />
      <Box 
        className= 'myPageBox'
        alignItems="space-between"
        sx={{ width: '100%', maxWidth: '600px', mx: 'auto', my: 2 }}
      >
        <AvatarSection userId = 'user1'/>
        <hr/>
        <ActivitySection />
        <hr />
      </Box>
      <Box
        className= 'myPageBox'
        alignItems="space-between"
        sx={{ width: '100%', maxWidth: '600px', mx: 'auto', my: 2 }}
      >
        <Typography variant="subtitle1" className="typography-muted" >
          내 정보
        </Typography>
        <MyInformation/>
      </Box>
    </ThemeProvider>
  );
};

export default LoginMypage;


import Box from '@mui/material/Box';
import { useState } from "react";
import { createTheme, ThemeProvider } from "@mui/material";
import LoginNavbar from './loginbar/LoginNavbar';



function LoginMainPage() {
  const [mode, setMode] = useState("light"); // Define theme mode state

  const theme = createTheme({
    palette: {
      mode: mode, // Use state for mode
    },
    typography: {
      fontFamily: "Gaegu, sans-serif", // Set the font family to Gaegu
    },
  });

  return (
    <ThemeProvider theme={theme}>
      <Box bgcolor={"background.default"} color={"text.primary"}>
        <LoginNavbar/>
        <LoginMainBar/>
        <SlideSide />
        <MiddleBar />
        {[1,2,3,4,5,6,7,8].map(i=><Contents />)}

        
      </Box>
    </ThemeProvider>
  );
}

export default LoginMainPage;

import React, { useState } from 'react';

import ButtonSection from '../components/mypage/ButtonSection';
import ProgramSection from '../components/mypage/ProgramSection';
import DeadlineSection from '../components/mypage/DeadlineSection';
import { Box, createTheme, ThemeProvider } from '@mui/material';
import MainBar from '../components/frontpage/MainBar';
import Navbar from '../components/frontpage/Navbar';
import AvatarSection from '../components/mypage/AvatarSection';
import BackBtnSection from './BackBtnSection';

const OrderPage = () => {
  const [mode, setMode] = useState("light");
    const darkTheme = createTheme({
    palette: {
      mode: mode,
    },
    typography: {
      fontFamily: "Gaegu, sans-serif",
    },
  });

  return (
    <ThemeProvider theme={darkTheme}>
      <Navbar />
      <MainBar />
      <Box
        display="flex"
        flexDirection="column"
        alignItems="space-between"
        sx={{ width: '100%', maxWidth: '600px', mx: 'auto', my: 2 }}
      >
      <AvatarSection/>
      <hr />
      <BackBtnSection/>
      <hr />
      <ButtonSection />
      <ProgramSection />
      <hr />
      <DeadlineSection />
      </Box>
    </ThemeProvider>
  );
};

export default OrderPage;

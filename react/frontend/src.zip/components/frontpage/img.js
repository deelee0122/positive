const imageData = [
  {
    label: "Image 1",
    alt: "image1",
    url: "https://plus.unsplash.com/premium_vector-1723516983074-bb96b8777ba7?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mzd8fGhvYmJ5fGVufDB8fDB8fHww",
  },
  {
    label: "Image 2",
    alt: "image2",
    url: "https://plus.unsplash.com/premium_vector-1682306946109-e5cf2d79d833?q=80&w=870&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    },
  {
    label: "Image 3",
    alt: "image3",
    url: "https://plus.unsplash.com/premium_vector-1683133905082-4f1b80c42305?q=80&w=870&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    },
  {
    label: "Image 4",
    alt: "image4",
    url: "https://plus.unsplash.com/premium_vector-1682303457162-7b7758d44636?q=80&w=898&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    },
  {
    label: "Image 5",
    alt: "image5",
    url: "https://plus.unsplash.com/premium_vector-1682300452346-026dc4f4cfab?q=80&w=829&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    },
  
  
  // 추가 이미지 데이터
];

export default imageData;

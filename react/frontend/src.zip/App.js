import { Routes, Route } from "react-router-dom";
import Box from '@mui/material/Box';
import MainPage from "./components/pages/MainPage"
import SubPage from "./components/pages/SubPage"
import SPWPage from "./components/pages/SPWPage"
import FitnessPage from "./components/pages/categoryPages/FitnessPage"
import CategoryPage from "./components/pages/categoryPages/CategoryPage"
import BeautyPage from "./components/pages/categoryPages/BeautyPage"
import DIYPage from "./components/pages/categoryPages/DIYPage"
import CookingPage from "./components/pages/categoryPages/CookingPage"
import ProductPage from "./components/pages/ProductPage"
import SignUpPage from "./components/pages/SignUpPage"
import Mypage from "./components/pages/Mypage"
import OrderPage from "./components/pages/OrderPage"
import LoginForm from "./components/login/LoginForm"
import LoginMainPage from "./components/pages/loginPage/LoginMainPage"
import LoginMypage from "./components/pages/loginPage/LoginMypage"
import LogoutMainPage from "./components/pages/logoutPage/LogoutMainPage"
import LogoutMypage from "./components/pages/logoutPage/LogoutMypage"

function App() {
  return (
    <Box>
        <Routes>
        <Route path="/" element={<MainPage />} />
        <Route path="/user" element={<SubPage />} />
        <Route path="/fitness" element={<FitnessPage />} />
        <Route path="/findpassword" element={<SPWPage />} />
        <Route path="/category" element={<CategoryPage />} />
        <Route path="/beauty" element={<BeautyPage />} />
        <Route path="/diy" element={<DIYPage />} />
        <Route path="/cooking" element={<CookingPage />} />
        <Route path="/productpage" element={<ProductPage />} />
        <Route path="/signup" element={<SignUpPage />} />
        <Route path="/mypage" element={<Mypage />} />
        <Route path="/order" element={<OrderPage/>} />
        <Route path="/login" element={<LoginForm/>} />
        <Route path="/loginMain" element={<LoginMainPage/>} />
        <Route path="/loginMy" element={<LoginMypage/>} />
        <Route path="/logoutMain" element={<LogoutMainPage/>} />
        <Route path="/logoutMy" element={<LogoutMypage/>} />
      </Routes>
      

    </Box>
  );
}

export default App;
